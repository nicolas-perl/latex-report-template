# Latex Protocol Template

The perfect academic template to write your next report! Especially at the FH Joanneum.

## Setup

by downloading the .zip file, you may import it right away to Overleaf by clicking **new Project** and **Upload Project**!

Simply adapt the template to your preferences by changing the default parameters in the frontpage.tex and params.tex

## structure

The latex part of the project is all located in the `src` folder. The entry-file in each folder is called `index.tex`.

### params.tex

This file contains a set of commands with information given in the setup process. Change this information to your preferences.

### config

This folder contains the different configurations for the document.

### pages

This folder is used for the actual content of the document (beside the main.tex).

The device list folder contains a preset of laboratory equipment, which can be changed and added to the document depending on your needs.
The signatures of the report contributors shall be added in the /src/config/signatures folder.
Optional attachments can be added in the dedicated attachments.tex file.